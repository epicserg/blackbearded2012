$(document).ready(function(){
	$('#front').fadeIn(1000);
	$('#end').fadeIn(4000);
	$('#makeBeauty').fadeIn(2000);
	
});

